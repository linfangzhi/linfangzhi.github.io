// Shared storefront behavior.
(function ($) {
    "use strict";

    const initCarousel = (selector, options) => {
        if ($(selector).length) {
            $(selector).owlCarousel(options);
        }
    };

    window.setTimeout(() => {
        const spinner = document.getElementById("spinner");
        if (spinner) {
            spinner.style.display = "none";
        }
    }, 800);

    initCarousel(".banner-slider", {
        loop: true,
        autoplay: true,
        dots: false,
        autoplayTimeout: 5000,
        nav: false,
        margin: 10,
        responsive: {
            0: { items: 1 },
            600: { items: 1 },
            1000: { items: 1 }
        }
    });

    initCarousel(".ls-product-slider", {
        loop: true,
        autoplay: true,
        dots: false,
        autoplayTimeout: 8000,
        nav: true,
        margin: 10,
        responsive: {
            0: { items: 1, nav: false },
            600: { items: 1, nav: false },
            1000: { items: 1 }
        }
    });

    initCarousel(".slide-ls-post", {
        loop: true,
        autoplay: true,
        dots: false,
        autoplayTimeout: 8000,
        nav: false,
        margin: 10,
        responsive: {
            0: { items: 1 },
            600: { items: 1 },
            1000: { items: 1 }
        }
    });

    initCarousel(".most-popular-category", {
        loop: true,
        autoplay: false,
        dots: false,
        nav: true,
        margin: 20,
        responsive: {
            0: { items: 3 },
            600: { items: 4 },
            1000: { items: 4 },
            1300: { items: 6 }
        }
    });

    initCarousel(".best-sell-slider-item", {
        loop: true,
        autoplay: false,
        dots: false,
        nav: true,
        margin: 0,
        responsive: {
            0: { items: 1 },
            600: { items: 3 },
            1000: { items: 4 },
            1300: { items: 5 }
        }
    });

    initCarousel(".most-popular-pd-sl", {
        loop: true,
        autoplay: false,
        dots: false,
        nav: true,
        margin: 0,
        responsive: {
            0: { items: 1 },
            600: { items: 3 },
            1000: { items: 4 },
            1300: { items: 5 }
        }
    });

    initCarousel(".trending-product-sl", {
        loop: true,
        autoplay: false,
        dots: false,
        nav: true,
        margin: 0,
        responsive: {
            0: { items: 1 },
            600: { items: 3 },
            1000: { items: 4 },
            1300: { items: 5 }
        }
    });

    initCarousel(".partner-slider", {
        loop: true,
        autoplay: false,
        dots: false,
        nav: false,
        margin: 10,
        responsive: {
            0: { items: 3 },
            600: { items: 4 },
            1000: { items: 5 },
            1500: { items: 7 }
        }
    });

    const cartToggle = document.getElementById("cartCardToggle");
    const cartDropdown = document.getElementById("toggleCard");
    if (cartToggle && cartDropdown) {
        cartToggle.addEventListener("click", (event) => {
            event.preventDefault();
            cartDropdown.classList.toggle("show");
        });
    }

    $(window).on("scroll", function () {
        const isScrolled = $(this).scrollTop() > 50;
        $(".main-header").toggleClass("navbar-fixed", isScrolled);
    });

    $("#category-parent").on("click", function (event) {
        event.preventDefault();
        $(".category-top-menu").toggleClass("active");
    });

    $(document).on("click", ".menus li", function () {
        $(this).addClass("active-icon").siblings().removeClass("active-icon");
    });

    if ($("#category-list").length) {
        $("#category-list li").on("click", function () {
            $(this).toggleClass("active");
        });
    }

    if ($("#slider-range").length && $.ui && $.ui.slider) {
        $("#slider-range").slider({
            range: true,
            min: 0,
            max: 1000,
            values: [10, 800],
            slide: function (event, ui) {
                $("#amount").html("$" + ui.values[0] + " - $" + ui.values[1]);
                $("#amount1").val(ui.values[0]);
                $("#amount2").val(ui.values[1]);
            }
        });

        $("#amount").html(
            "$" + $("#slider-range").slider("values", 0) +
            " - $" + $("#slider-range").slider("values", 1)
        );
    }

    const customSelects = document.getElementsByClassName("custom-select");
    for (let i = 0; i < customSelects.length; i += 1) {
        const select = customSelects[i].getElementsByTagName("select")[0];
        if (!select) {
            continue;
        }

        const selected = document.createElement("div");
        selected.setAttribute("class", "select-selected");
        selected.innerHTML = select.options[select.selectedIndex].innerHTML;
        customSelects[i].appendChild(selected);

        const options = document.createElement("div");
        options.setAttribute("class", "select-items select-hide");

        for (let j = 1; j < select.length; j += 1) {
            const option = document.createElement("div");
            option.innerHTML = select.options[j].innerHTML;
            option.addEventListener("click", function () {
                const source = this.parentNode.parentNode.getElementsByTagName("select")[0];
                const current = this.parentNode.previousSibling;
                for (let k = 0; k < source.length; k += 1) {
                    if (source.options[k].innerHTML === this.innerHTML) {
                        source.selectedIndex = k;
                        current.innerHTML = this.innerHTML;
                        const active = this.parentNode.getElementsByClassName("same-as-selected");
                        for (let idx = 0; idx < active.length; idx += 1) {
                            active[idx].removeAttribute("class");
                        }
                        this.setAttribute("class", "same-as-selected");
                        break;
                    }
                }
                current.click();
            });
            options.appendChild(option);
        }

        customSelects[i].appendChild(options);
        selected.addEventListener("click", function (event) {
            event.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
        });
    }

    function closeAllSelect(element) {
        const optionLists = document.getElementsByClassName("select-items");
        const selectedItems = document.getElementsByClassName("select-selected");
        const activeIndexes = [];

        for (let i = 0; i < selectedItems.length; i += 1) {
            if (element === selectedItems[i]) {
                activeIndexes.push(i);
            } else {
                selectedItems[i].classList.remove("select-arrow-active");
            }
        }

        for (let i = 0; i < optionLists.length; i += 1) {
            if (activeIndexes.indexOf(i) === -1) {
                optionLists[i].classList.add("select-hide");
            }
        }
    }

    document.addEventListener("click", closeAllSelect);

    $("#filter-btn").on("click", function (event) {
        event.preventDefault();
        $("#filter-menu").addClass("active");
        $("#hidden-div").addClass("active");
    });

    $("#hidden-div").on("click", function () {
        $("#filter-menu").removeClass("active");
        $("#hidden-div").removeClass("active");
    });

    if ($(".sp-wrap").length && $.fn.smoothproducts) {
        $(window).on("load", function () {
            $(".sp-wrap").smoothproducts();
        });
    }

    $(".quantity").on("click", ".plus", function () {
        const input = $(this).prev("input.qty");
        const value = parseInt(input.val(), 10) || 0;
        input.val(value + 1).change();
    });

    $(".quantity").on("click", ".minus", function () {
        const input = $(this).next("input.qty");
        const value = parseInt(input.val(), 10) || 0;
        if (value > 0) {
            input.val(value - 1).change();
        }
    });

    const subscribeNode = document.getElementById("subscribeModel");
    if (subscribeNode && window.bootstrap && bootstrap.Modal) {
        const subscribeModal = new bootstrap.Modal(subscribeNode);
        window.setTimeout(() => subscribeModal.show(), 20000);
    }
})(jQuery);
